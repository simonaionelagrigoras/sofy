#/bin/bash

# Red Hat Linux Advanced Server => CentOS
# Red Hat Linux => CentOS
# Red Hat, Inc. => CentOS
# Red Hat => CentOS
# www.redhat.com => www.centos.org
# RedHat/ => CentOS/

for i in `find . -type f` ; do
   echo $i
   #file $i
   TMPFILE=`mktemp /tmp/$0.XXXXXX` || exit 1
   cat $i | sed 's/Red Hat Linux Advanced Server/CentOS/g ; 
                 s/Red Hat Linux/CentOS/g ;
                 s/Red Hat, Inc./CentOS/g ;
                 s/0cRed Hat/0aCentOS/g ;
                 s/Red Hat/CentOS/g ;
                 s/www.redhat.com/www.centos.org/g ;
                 s/RedHat\//CentOS\//g' > $TMPFILE
   cp $TMPFILE $i
   rm $TMPFILE
done
